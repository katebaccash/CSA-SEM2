import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import java.awt.Color;

public class Boulder extends Actor
{
	private int lifeTime;
	private final int threshold = 3;
	
	public Boulder()
	{
		setColor(null);
		lifeTime = (int)(Math.random() * 200) + 1;
	}
	
	public Boulder(int life)
	{
		setColor(null);
		lifeTime = life;
	}
	
	public void act()
	{
		if(lifeTime == 0)
		{
			Kaboom kaboom = new Kaboom();
			kaboom.putSelfInGrid(getGrid(), getLocation());
			removeSelfFromGrid();
		}
		else if(lifeTime < threshold)
		{
			setColor(Color.RED);
			lifeTime--;
		}
		else
			lifeTime--;
	}
}
