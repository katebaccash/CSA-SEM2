import info.gridworld.actor.Bug;
import java.awt.Color;
import info.gridworld.grid.Grid;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Location;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Flower;

public class Jumper extends Bug {
	
	public Jumper() {
		super(Color.BLUE);
	}
	
	public void act() {
		if (canMove())
            move();
        else
            turn();
	}
	
	public void move() {
		Grid<Actor> gr = getGrid();
        if (gr == null)
            return;
        Location loc = getLocation();
        Location adjacent = loc.getAdjacentLocation(getDirection());
        Location next = adjacent.getAdjacentLocation(getDirection());
        if (gr.isValid(next))
            moveTo(next);
        else
            removeSelfFromGrid();
		
		Blossom flower = new Blossom();
        flower.putSelfInGrid(gr, loc);
	}
	
	public boolean canMove() {
		Grid<Actor> gr = getGrid();
        if (gr == null)
            return false;
        Location loc = getLocation();
        Location adjacent = loc.getAdjacentLocation(getDirection());
        Location next = adjacent.getAdjacentLocation(getDirection());
        
        if (gr.isValid(next) && !(gr.get(next) == null || (gr.get(next) 
			instanceof Flower && !(gr.get(next) instanceof Blossom))))
            return true;
		return false;
	}
}
