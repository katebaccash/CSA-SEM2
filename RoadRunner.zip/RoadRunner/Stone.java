import info.gridworld.actor.Rock;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import java.awt.Color;

public class Stone extends Rock
{
	private int lifeTime;
	private final int threshold = 3;
	
	public Stone()
	{
		setColor(null);
		lifeTime = (int)(Math.random() * 200) + 1;
	}
	public Stone(int life) 
	{
		setColor(null);
		lifeTime = life;
	}
	
	public void act()
	{
		if(lifeTime == 0)
		{
			lifeTime--;
			Boulder b = new Boulder();
			b.putSelfInGrid(getGrid(), getLocation());
			(removeSelfFromGrid);
		}
		else if(lifeTime < threshold)
		{
			setColor(Color.GREEN);
			lifeTime--;
		}
		else
			lifeTime--;
	}
}
