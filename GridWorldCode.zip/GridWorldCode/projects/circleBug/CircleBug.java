import info.gridworld.actor.Bug;

/**
 *  Creates a Bug that steps in a circle.
 * 	@author Kate Baccash
 * 	@since 3/12/2025
 */
public class CircleBug extends Bug
{
	private int steps;
    private int sideLength;

    /**
     * Constructs a box bug that traces a circle.
     * @param length the side length
     */
    public CircleBug(int length)
    {
        steps = 0;
        sideLength = length;
    }

    /**
     * Moves to the next location of the circle.
     */
    public void act()
    {
        if (steps < sideLength && canMove())
        {
            move();
            steps++;
        }
        else
        {
            turn();
            steps = 0;
        }
    }
}
