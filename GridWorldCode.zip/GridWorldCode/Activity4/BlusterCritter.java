import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;

import java.util.ArrayList;
import java.awt.Color;

/**
 * A <code>BlusterCritter</code> gets lighter if there are less than c 
 * neighbors around it and gets darker if there are more as it moves 
 * through the grid. <br />
 */
public class BlusterCritter extends Critter
{
	private int courage;
	
	// Constructor with courage level
	public BlusterCritter(int cIn) {
		courage = cIn;
	}
	
	/**
	 * 	Gets a list of all the actors within 2 spaces of this critter.
	 * 	@return	an ArrayList of all the actors within 2 spaces of this critter
	 */
	public ArrayList<Actor> getActors() {
		ArrayList<Actor> actors = new ArrayList<Actor>();
		int[] directions = {Location.NORTH, Location.NORTHEAST, Location.EAST,
			Location.SOUTHEAST, Location.SOUTH, Location.SOUTHWEST, Location.WEST,
			Location.NORTHWEST};

		for(int d : directions) {
			Location adj = getLocation().getAdjacentLocation(d);
			if(getGrid().isValid(adj)) {
				if(getGrid().get(adj) != null)
					actors.add(getGrid().get(adj));
				int dir = getLocation().getDirectionToward(adj);
				if(getGrid().isValid(adj.getAdjacentLocation(dir)) &&
					getGrid().get(adj.getAdjacentLocation(dir)) != null)
					actors.add(getGrid().get(adj.getAdjacentLocation(dir)));
			}
		}
		return actors;
	}
	
	/**
	 * 	Turns this critter darker if the courage is greater than or equal
	 * 	to the amount of Actors in actors passed in.
	 * 	@param actors		the list of Actors to count
	 */
	public void processActors(ArrayList<Actor> actors) {
		int count = actors.size();
		double COLOR_FACTOR = 0.05;
		Color c = getColor();
		int red = c.getRed();
		int green = c.getGreen();
		int blue = c.getBlue();
			
		if(count < courage) {
			if((int)(c.getRed() * (1 - COLOR_FACTOR)) >= 0)
				red = (int) (c.getRed() * (1 - COLOR_FACTOR));
			if((int)(c.getGreen() * (1 - COLOR_FACTOR)) >= 0)
				green = (int) (c.getGreen() * (1 - COLOR_FACTOR));
			if((int)(c.getBlue() * (1 - COLOR_FACTOR)) >= 0)
				blue = (int) (c.getBlue() * (1 - COLOR_FACTOR));

			setColor(new Color(red, green, blue));
		}
		else {
			if((int)(c.getRed() * (1 + COLOR_FACTOR)) <= 255)
				red = (int) (c.getRed() * (1 + COLOR_FACTOR));
			if((int)(c.getGreen() * (1 + COLOR_FACTOR)) <= 255)
				green = (int) (c.getGreen() * (1 + COLOR_FACTOR));
			if((int)(c.getBlue() * (1 + COLOR_FACTOR)) <= 255)
				blue = (int) (c.getBlue() * (1 + COLOR_FACTOR));

			setColor(new Color(red, green, blue));
		}
	}
}
