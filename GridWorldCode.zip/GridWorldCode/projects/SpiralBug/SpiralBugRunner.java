
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;

import java.awt.Color;

/**
 *	This class runs a world that contains circle bugs.
 * 	@author Kate Baccash
 * 	@since 3/12/2025
 */
public class SpiralBugRunner
{
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
        SpiralBug alice = new SpiralBug(3);
        alice.setColor(Color.ORANGE);
        SpiralBug bob = new SpiralBug(2);
        world.add(new Location(9, 9), alice);
        world.add(new Location(3, 5), bob);
        world.show();
    }
}
