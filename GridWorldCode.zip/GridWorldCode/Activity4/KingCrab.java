import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;

import java.util.ArrayList;
import java.awt.Color;

/**
 * A <code>KingCrab</code> moves 1 space to its right or left and makes
 * neighboring actors who are in front, front-right, or front-left of it
 * move away from it as it moves through the grid. <br />
 */
public class KingCrab extends CrabCritter
{
	/**
	 * 	Moves all actors in actors passed in radially away from this KingCrab
	 * 	if they can move staying inside the grid. Otherwise, remove them
	 * 	from the grid.
	 * 	@param actors		the list of actors to move or remove from grid
	 */
	public void processActors(ArrayList<Actor> actors) 
	{
		if(!getGrid().getOccupiedLocations().isEmpty()) 
		{
			for(Actor a : actors)
			{
				int dir = getLocation().getDirectionToward(a.getLocation());
				Location moveLoc = a.getLocation().getAdjacentLocation(dir);
				if(getGrid().isValid(moveLoc))
					a.moveTo(moveLoc);
				else
					a.removeSelfFromGrid();
			}
		}
		else
			super.processActors(actors);
	}
}
