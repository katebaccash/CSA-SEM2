import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import info.gridworld.actor.Rock;

import java.util.ArrayList;
import java.awt.Color;

/**
 * A <code>RockHound</code> removes rocks within 1 space of it as it moves
 * through the grid. <br />
 */
public class RockHound extends Critter
{
	/**
	 *  Removes from the grid, all the actors who are Rocks in actors passed in.
	 * 	@param actors		the list of actors to remove if they are rocks
	 */
	public void processActors(ArrayList<Actor> actors) {
		for(Actor a : actors) {
			if(a instanceof Rock)
				a.removeSelfFromGrid();
		}
	}
}
