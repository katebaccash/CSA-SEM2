
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;

import java.awt.Color;

/**
 *	This class runs a world that contains dancing bugs.
 * 	@author Kate Baccash
 * 	@since 3/12/2025
 */
public class DancingBugRunner
{
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
        DancingBug alice = new DancingBug(5);
        alice.setColor(Color.ORANGE);
        world.add(new Location(3, 3), alice);
        world.show();
    }
}
