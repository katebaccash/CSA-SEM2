import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;

import java.util.ArrayList;
import java.awt.Color;

/**
 * A <code>ChameleonKid</code> takes on the color of the actor in front 
 * or behind it as it moves through the grid. <br />
 */
public class ChameleonKid extends ChameleonCritter
{
	/**
	 * 	Gets a list of the actors who are imediately in front and behind
	 * 	this ChameleonKid.
	 * 	@return		An ArrayList of the actors who are in front and behind,
	 * 				Empty if there are no Actors there
	 */
	public ArrayList<Actor> getActors() {
		ArrayList<Actor> actors = new ArrayList<Actor>();
		Location loc = getLocation();
		if(getGrid().isValid(loc.getAdjacentLocation(getDirection())) &&
			getGrid().get(loc.getAdjacentLocation(getDirection())) != null)
				actors.add(getGrid().get(loc.getAdjacentLocation(getDirection())));
		if(getGrid().isValid(loc.getAdjacentLocation(getDirection() + 180))
			&& getGrid().get(loc.getAdjacentLocation(getDirection() + 180))
			!= null)
				actors.add(getGrid().get(loc.getAdjacentLocation(getDirection()
				+ 180)));
		return actors;
	}
}
