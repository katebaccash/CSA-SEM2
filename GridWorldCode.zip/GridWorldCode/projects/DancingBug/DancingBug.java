import info.gridworld.actor.Bug;

/**
 *  Creates a Bug that steps in a dance.
 * 	@author Kate Baccash
 * 	@since 3/12/2025
 */
public class DancingBug extends Bug
{
	private int steps;
    private int sideLength;
    private int[] turns = { 1, 0, 0, 0, 1, 0, 0, 3, 4, 4, 0, 0, 1, 0, 
		3, 2, 0, 7, 0, 0, 0, 3, 2, 1 };

    /**
     * Constructs a box bug that traces a dance.
     * @param length the side length
     */
    public DancingBug(int length)
    {
        steps = 0;
        sideLength = length;
    }

    /**
     * Moves to the next location of the dance step.
     */
    public void act()
    {
		for(int i = 0; i < turns[steps]; i++)
		{
			turn();
		}
		if(canMove())
		{
			move();
			steps++;
		}
		steps = steps % turns.length;
    }
}
