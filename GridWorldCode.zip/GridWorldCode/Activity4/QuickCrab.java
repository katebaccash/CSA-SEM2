import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;

import java.util.ArrayList;
import java.awt.Color;

/**
 * A <code>QuickCrab</code> moves 2 spaces to its right or left and eats
 * actors who are in front, front right, and front left of it as it moves 
 * through the grid. <br />
 */
public class QuickCrab extends CrabCritter
{
	/**
	 * 	Gets the locations 2 spaces to the left and right if they are empty
	 * 	and their intervening locations are also empty.
	 * 	@return	ArrayList of the 2 locations to the left and right that
	 * 			are empty and their intervening locations are also empty.
	 */
	public ArrayList<Location> getMoveLocations()
	{
		ArrayList<Location> locs = new ArrayList<Location>();
		
		Location adj = getLocation().getAdjacentLocation(getDirection() 
			+ Location.RIGHT);
		Location moveLoc = adj.getAdjacentLocation(getDirection() + 
			Location.RIGHT);
		if(getGrid().isValid(adj) && getGrid().isValid(moveLoc) && 
			getGrid().get(adj) == null && getGrid().get(moveLoc) == null)
			locs.add(moveLoc);
		
		Location adj2 = getLocation().getAdjacentLocation(getDirection() 
			+ Location.LEFT);
		Location moveLoc2 = adj2.getAdjacentLocation(getDirection() + 
			Location.LEFT);
		if(getGrid().isValid(adj2) && getGrid().isValid(moveLoc2) && 
			getGrid().get(adj2) == null && getGrid().get(moveLoc2) == null)
			locs.add(moveLoc2);
			
		return locs;
	}
}
