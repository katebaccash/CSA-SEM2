import info.gridworld.actor.Bug;

/**
 *  Creates a Bug that steps in a Z shape.
 * 	@author Kate Baccash
 * 	@since 3/12/2025
 */
public class ZBug extends Bug
{
	private int steps;
    private int sideLength;
    private int turns;

    /**
     * Constructs a box bug that traces a Z.
     * @param length the side length
     */
    public ZBug(int length)
    {
        steps = 0;
        turns = 0;
        sideLength = length;
        turn();
        turn();
    }

    /**
     * Moves to the next location of the Z.
     */
    public void act()
    {
        if (steps < sideLength && canMove())
        {
            move();
            steps++;
        }
        else if(turns == 0)
        {
            turn();
            turn();
            turn();
            steps = 0;
            turns++;
        }
        else if(turns == 1)
        {
			turn();
            turn();
            turn();
            turn();
            turn();
            steps = 0;
            turns++;
		}
    }
}
